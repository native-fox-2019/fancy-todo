
let $navregister =$("#navbar-register")
let $navlogin= $("#navbar-login")
let $form_register = $("#form-register")
let $form_login = $("#form-login")
let $form_todos=$("#form-todos")
let $regEmail=$("#form-register-email")
let $regId =$("#form-register-name")
let $regPassword = $("#form-register-password")
let $notifreg = $("#notifreg")
let $email = $("#email")
let $password = $("#password")
let $pwderror= $("#loginfail")
let $addTodo = $("#trigger-add-todo")
let $form_addTodo = $("#div-add-todos")



$(document).ready(function(){
    if (localStorage.getItem("token")){
        $form_login.hide()
        $form_register.hide()
                //$form_todos.show(300)
                getAllTodo()
    }
})

$navregister.on("click", ()=>{
    $form_register.show()
    $form_login.hide()
})

$navlogin.on("click", ()=>{
    
    $form_register.hide()
    $form_login.show()
})



$form_register.on("submit",function (e) { 
    e.preventDefault();
    registerUser($regId.val(), $regEmail.val(), $regPassword.val() )
    $form_login.show()
    $form_register.hide()
    $notifreg.show(500)
    $notifreg.hide(5000)
});



$form_login.on("submit",function (e){
    e.preventDefault();
    login($email.val(), $password.val())
    
})

$addTodo.on("click",function(){
    $form_todos.hide()
    $form_addTodo.show()
})

$("#form-addTodo").on("submit", function(e){
    e.preventDefault()
    insertTodo($("#title").val(), $("#description").val(), $("#due_date").val())
    console.log('udah ambil baru')
    $form_addTodo.hide();
})

$("#nalogout").on("click", function(){
    localStorage.removeItem("token")
    $("#submit-form-login")[0].reset()
    $("#navLogin").hide()
    $("#nav").show()
    signOut()
    location.reload()

})

//================function ==============================


function signOut() {
    var auth2 = gapi.auth2.getAuthInstance();
    auth2.signOut().then(function () {
      console.log('User signed out.');
    });
  }


function registerUser (name,email,password){
    $.ajax({
        url:"http://localhost:3001/users/register",
        method:"post",
        contentType:"application/json",
        data:JSON.stringify({
            name:name,
            email:email,
            password:password
        }),
        success:function(data){
            console.log('sukses')
        }
    })    
}

function login(email,password){
    $.ajax(
        {
            url:"Http://localhost:3001/users/login",
            method:"post",
            contentType:"application/json",
            data:JSON.stringify({
                email:email,
                password:password,
            }),
            success:function(result){
                localStorage.setItem("token", result.token)
                $form_login.hide()
                $form_register.hide()
                //$form_todos.show(300)
                getAllTodo()
                $("#navLogin").show()
                $("#nav").hide()
            },
            error: function(xhr){
                //callback(false, xhr.statusText, xhr.status)
                $("#loginfail").show()
                $("#loginfail").fadeOut(5000)
            }
        }
    )
}

function getAllTodo(){
    // console.log('token: ',localStorage.getItem("token"))
    // console.log(timess)  
    $.ajax({
        url:"http://localhost:3001/todos",
        method:"get",
        contentType:"application/json",
        headers:{token:localStorage.token},
        success:function(res){
            $("#todo-list tr").remove();
            res.forEach(element=>{
                console.log(element.id)
                let title = `qrDescription${element.id}`
                console.log(title)
                let desc = `qrDescription${element.id}`
                
                $("#todo-list").append(
                    `<tr>
                        <td> <button type="button" class="btn btn-outline-primary btn-lg" data-toggle="modal" data-target="#exampleModalCenter" id="qrTitle${element.id}" onclick="bodo(${element.id})"  > ${element.title}   </button></td>
                        <td id="qrDescription${element.id}">  ${element.description}</td>
                        <td id="qrDuedate${element.id}"> ${element.due_date} </td>
                        <td>   
                        <a class="btn btn-primary" onclick="editForm(${element.id})" > Edit </a>
                            <a class="btn btn-danger" onclick="deleteTodo(${element.id})" > Delete </a> </td>
                    </tr>
                    ${$("#qrCode img").remove()}
                    ${$("#qrCode").append(
                        `<img src="http://api.qrserver.com/v1/create-qr-code/?data=kegiatan: ${element.title} Deskripsi:${element.description}">`
                    )}
                    `)
                
            });
            $form_todos.show()
            $form_register.hide()
            $form_login.hide()
            console.log($("#qrDescription6").text())
        },
        error: function(xhr){
            console.log('error')
            //(xhr,null)
        }
    })
}

function bodo (title){
    let a= `#qrTitle${title}`
    let b= `#qrDescription${title}`
    let judul =$(a).text()
    let desk =$(b).text()
    
    console.log( judul,desk,'inititle')
    // console.log(title)
    $("#qrCode img").remove()
    $("#qrCode").append(`
    <img src="http://api.qrserver.com/v1/create-qr-code/?data=kegiatan: ${judul}  Deskripsi:${desk}">
    `)
}



function insertTodo(title,description,due_date){
    $.ajax(
        {
        url:"Http://localhost:3001/todos",
        method:"post",
        contentType:"application/json",
        headers:{token:localStorage.token},
        data:JSON.stringify({
            title:title,
            description:description,
            due_date:due_date,
            status:"uncompleted"
        }),
        success:function(res){
            // console.log(res,"ini sukses add")
            getAllTodo()
        },
        error: function(res){
            // console.log(res,"ini error add todo")
        }
        }
    )
}

function deleteTodo(id){
    $.ajax(
        {
            url:`Http://localhost:3001/todos/${Number(id)}`,
            method:"delete",
            headers:{token:localStorage.token},
            success:function(data){
                console.log(data,"delete sukses")
                getAllTodo()
            },
            error: function(err){
                console.log(err,"error delete")
            }
        }
    )
}

function editForm(id){
    $.ajax(
        {
            url:`Http://localhost:3001/todos/${Number(id)}`,
            method:"get",
            headers:{token:localStorage.token},
            success:function(data){
                $("#div-edit-todos").show()
                $form_todos.hide()
                console.log(data)
                let Tgl = new Date(data.due_date)
                let date = String(Tgl.getDate()).padStart(2,'0')
                let month = String(Tgl.getMonth()+1).padStart(2,'0')
                let year = Tgl.getFullYear()
                let today = `${year}-${month}-${date}`
                console.log(today)
                $("#div-edit-todos").append(`
                <form id ="form-editTodo" style="text-align: center;">
                        <input readonly value=${data.id} id="edit-id"><br><br>
                        <label style="text-align: left;"> title: </label><br>
                        <input type="text" id="edit-title" placeholder="title" value="${data.title}"><br><br>
                        <label> description: </label><br>
                        <input type="text" id="edit-description" placeholder="description.." value="${data.description}" ><br><br>
                        <label> Due Date: </label><br>
                        <input type="date" id="edit-due_date" placeholder="title" value="${today}" > <br><br>
                        <label>Status :</label><br><br>
                        <select id="edit-status">
                            <option value="completed" ${data.status==="completed" ? "selected" : ""} >completed</option>
                            <option value="uncompleted"  ${data.status==="uncompleted" ? "selected" : ""}>uncompleted</option>
                        </select><br><br>
                        <input type="submit" value="Edit Todo" class="btn btn-primary">
                    </form>
                `)

                $("#form-editTodo").on("submit",function(e){
                    e.preventDefault()
                    console.log("kesubmit dong")
                    let $id= $("#edit-id").val()
                    let $editTitle =$("#edit-title").val()
                    let $editDesc = $("#edit-description").val()
                    let $editDate = $("#edit-due_date").val()
                    let $editStatus = $("#edit-status").val()
                    editData($id,$editTitle,$editDesc,$editDate,$editStatus)
                
                })
                
            }

        }
    )
}

function editData(id,title,description,due_date,status){
    $.ajax(
        {
            url:`Http://localhost:3001/todos/${Number(id)}`,
            method:"put",
            headers:{token:localStorage.token},
            contentType:"application/json",
            data:JSON.stringify({
                title:title,
                description:description,
                due_date:due_date,
                status:status
            }),
            success:function(data){
                console.log(data,"sukses")
                getAllTodo()
            },
            error:function(err){
                console.log(err,"error")
            }

        }
    )
    $("#div-edit-todos").hide()
}

//======================= GUGLE SIGN IN ======================

function onSignIn(googleUser) {
    console.log('masuk fangsyen onSignIn')
    var id_token = googleUser.getAuthResponse().id_token;
    $.ajax({
        method: "POST",
        url: "Http://localhost:3001/users/glSign",
        data: {
            token:id_token
        },
        success: function (response) {
           console.log('sukses')
           localStorage.setItem("token", response.token)
           $form_login.hide()
           $form_register.hide()
           $form_todos.show(300)
           $("#navLogin").show()
           $("#nav").hide()
           getAllTodo()

        },
        error: function(jqXHR,error,thrownErr){
            console.log(jqXHR.status, jqXHR.statusMessage,'tidak sukses')
        }
    });
  }